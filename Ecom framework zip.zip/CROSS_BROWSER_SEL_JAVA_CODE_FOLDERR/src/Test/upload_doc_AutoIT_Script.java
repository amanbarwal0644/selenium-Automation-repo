package Test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

public class upload_doc_AutoIT_Script {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		
		String download_path = System.getProperty("user.dir");
		
		
		FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("browser.download.dir", download_path);
        profile.setPreference("browser.download.folderList", 2);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
		
        FirefoxOptions a = new FirefoxOptions();
        a.setProfile(profile);
        
      //  ChromeOptions as = new ChromeOptions();
        
        
        
      
		
		//System.setProperty("Webdriver.gecko.driver", "C:\\Users\\admin\\Selenium_browser_driver\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver(a);
		
	//	WebDriver driver = new ChromeDriver(opt);
		
		driver.get("https://www.ilovepdf.com/jpg_to_pdf");
		
		
	//	driver.findElement(By.id("file-upload")).click();
	/*	
		WebElement l = driver.findElement(By.id("file-upload"));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", l);
		*/
		WebElement Target = driver.findElement(By.xpath("//a[@id='pickfiles']"));
		
		
		
		Actions act =  new Actions(driver);
		
		act.moveToElement(Target).click().build().perform();
		
		
		
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		Runtime.getRuntime().exec("C:\\Users\\admin\\OneDrive\\Desktop\\AutoITDEsktop4\\uploadscript1.exe");
		
		Thread.sleep(10000);
		
		
		driver.findElement(By.id("processTask")).click();
		
	
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		driver.findElement(By.partialLinkText("Download PDF")).click();
		
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		File xx = new File(download_path+"\01-4.pdf");
		
	//	C:\Users\admin\eclipse-workspace\CROSS_BROWSER_SEL_JAVA_CODE_FOLDERR\01-19
		
		//C:\Users\admin\eclipse-workspace\CROSS_BROWSER_SEL_JAVA_CODE_FOLDERR
		
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(xx.exists()) {
			System.out.println("file has been found");
		}
		else{
System.out.println("not found");
		}
		
		xx.delete();
	//	C:\Users\admin\eclipse-workspace\CROSS_BROWSER_SEL_JAVA_CODE_FOLDERR\01-4
		
		
		
		
	}

}
