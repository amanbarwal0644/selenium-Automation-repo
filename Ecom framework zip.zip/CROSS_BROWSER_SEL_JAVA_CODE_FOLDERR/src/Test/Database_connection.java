package Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.mysql.cj.xdevapi.Result;

public class Database_connection {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		
		//DriverManager.getConnection(url, username, password);
		Connection con = DriverManager.getConnection("jdbc:mysql://"+"localhost:"+"3306"+"/amanTest", "root", "BaRWAL#5");
		
		Statement s = con.createStatement();
		
	ResultSet re = 	s.executeQuery("select * from prsn_addr where prsn_intn_id='8725845774' ");
	
	
	re.next();
	
	System.out.println(re.getString("prsn_email"));
	
	System.out.println(re.getInt("postal_code"));
		
		
	WebDriver driver = new FirefoxDriver();
	
	driver.get("https://login.salesforce.com/");
		driver.findElement(By.id("username")).sendKeys(re.getString("prsn_email"));
		
		driver.findElement(By.id("password")).sendKeys(re.getString("postal_code"));
		
		
	}

}
