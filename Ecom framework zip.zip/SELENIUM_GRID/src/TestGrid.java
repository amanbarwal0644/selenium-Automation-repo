import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TestGrid {

	
	public void test() throws MalformedURLException {
		// TODO Auto-generated method stub

		
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability(CapabilityType.BROWSER_NAME, "firefox");
		
		WebDriver driver  = new RemoteWebDriver(new URL("http://172.20.10.3:4444"),caps);
		
		
		driver.get("https://login.salesforce.com/");
		
		
		
	}
	
}
