package Program_Code_Container;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Mobile_test_case {

	@Test
	public void mobile_login_samsung() {
		System.out.println("mobile login successfull samsung");
	}
	
	
	@Test
	public void mobile_login_ONE_PLUS() {
		System.out.println("mobile login successfull ONE PLUS");
	}
	
	@BeforeTest
	public void mobile_logout_Zoo() {
		System.out.println(" i will execute first");
	}
	
	
	@AfterTest
	public void mobile_login_Xiomi() {
		System.out.println("I will execute last");
	}
	
}
