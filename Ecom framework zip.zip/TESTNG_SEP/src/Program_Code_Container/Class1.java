package Program_Code_Container;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class Class1 {

	@Test
	public void testcase1() {
System.out.println("hello");	
	}
	
	@AfterSuite
	public void testcase2() {
		System.out.println("After suite exe i am executing");
	}
	
	
	@Test(groups= {"smoke"})
	public void Smokecase1() {
		System.out.println("smoke acse1");
	}
}
