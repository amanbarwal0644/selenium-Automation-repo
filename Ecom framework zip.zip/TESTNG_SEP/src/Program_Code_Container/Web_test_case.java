package Program_Code_Container;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Web_test_case {

	@Test

	public void web_login() {
		System.out.println("web_login_successfull");
		
		
	}
	
	
	@Test
	public void web_method2() {
		System.out.println("method 2 of web");
	}
	
	
	@BeforeMethod
	public void bofore_method() {
		System.out.println("AM BEFORE METHOD EXE BEFORE EACH TEST METHOD");
	}
	
	
	
	@Test(groups= {"smoke"})
	public void Smokecase2() {
		System.out.println("smoke case2");
	}
	
}
