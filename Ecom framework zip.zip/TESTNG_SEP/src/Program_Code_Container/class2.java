package Program_Code_Container;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class class2 {

	@BeforeSuite
	public void secondfile() {
	System.out.println("class 2 case  before suite exe am executing");
		
	}
	
}
