
public abstract class Parent_abstract {

	
	public void Aircraft_design() {
		System.out.println("follow standard guidelines");
	}
	
	public  abstract void color();
	
	
	
	
}
