import java.io.Console;

public class practice_oops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		
		// Reverse string
		
		String X="Aman kumar";
		
		     StringBuilder inp = new StringBuilder(X);
		     
		     System.out.print(inp.reverse()+"    builder");
		int count = 0;

		
		for (int i=0;i<X.length();i++)
		{
			
			count =X.length();			
			
			
		}
		
		
		for(int j=count-1;j>=0;j--) {
			System.out.print(X.charAt(j));
		}
		
		
		// star pattern program
		/*    *
		 *    **
		 *    ***
		 *    ****
		 *    *****
		 * 
		 * 
		 */
		
		/*
		System.out.println("");
		int row=5,col=5;
		
		for(int i=0;i<=row;i++) {
			
			for(int j=0;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		
		System.out.println("");
		
		
		/*    *****
		 *     ****
		 *      ***
		 *       **
		 *        *
		 */
		/*
		
		int rows=5;
		for(int k=0;k<=rows;k++) {
			
		
			for(int m=0;m<=k;m++) {
				System.out.print(" ");
			}
			for(int l=0+k;l<=rows;l++) {
				
				System.out.print("*");
			}
			
			System.out.println("");
		}
			
		
		/*         *
		 *        ***
		 *       *****
		 *      ******* 
		 * 
		 */
		
		int z=0;
		
		for(int x=0;x<4;x++) {
			
			for(int y=0+x;y<5;y++) {
				System.out.print(" ");
			}
			
			for(z=0;z<x+1;z++) {
				System.out.print("*");
			}
			
			
			for(int g=1;g<x+1;g++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		
			
			
		
		
		
		
		
	}

}
