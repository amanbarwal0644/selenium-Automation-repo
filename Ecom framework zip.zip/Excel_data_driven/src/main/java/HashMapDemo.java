import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		HashSet Hs= new HashSet();
		Hs.add("Hashset 1");
		Hs.add("Hashset 2");
		Hs.add("Hashset 3");
		Hs.add("Hashset 4");
		
		System.out.print(Hs);
		
Iterator it = Hs.iterator();

while(it.hasNext()){
	System.out.println(it.next());
	
}
		
		HashMap<Integer,String> hm = new HashMap<Integer, String>();
		
		hm.put(0, "Aman");
		hm.put(1, "kumar");
		hm.put(2, "Barwal");
		
		System.out.println(hm);
Set s = hm.entrySet();

Iterator it2 = s.iterator();


while(it2.hasNext()) {
//System.out.println(it2.next());

Map.Entry ME=(Map.Entry)it2.next();

System.out.println(ME.getKey());
System.out.println(ME.getValue());

}
		
		
	}

}
