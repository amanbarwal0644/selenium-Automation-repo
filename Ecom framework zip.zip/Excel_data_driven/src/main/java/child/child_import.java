package child;

public class child_import {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
