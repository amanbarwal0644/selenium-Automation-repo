
public interface Centeral_terraifc {

	
	public void green() ;
	public void red();
	public void yellow();
	
	
}
