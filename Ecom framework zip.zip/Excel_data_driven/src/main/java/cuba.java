import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class cuba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	
			// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
		
			
			
			
			WebDriver driver =  new FirefoxDriver();
			
			driver.get("https://www.amazon.in/ap/register?openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fref%3Drhf_sign_in&openid.assoc_handle=inflex");
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3000));
			
			driver.findElement(By.id("ap_customer_name")).sendKeys("Aman");
			driver.findElement(By.id("ap_phone_number")).sendKeys("123456789");
			driver.findElement(By.id("ap_password")).sendKeys("Aman#5123");
			
			
		//	WebDriverWait  wait = new WebDriverWait(WebDriver driver,3000);
			
		//	wait.until(ExpectedConditions.elementToBeClickable(By.id("continue")));
			
			//driver.findElement(By.id("continue")).click();
			
			

			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
 			driver.get("https://www.amazon.in/ref=navm_hdr_logo");
			
			

			
			System.out.println(driver.findElement(By.tagName("a")));
			
		String tp = 	driver.findElement(By.id("glow-ingress-single-line")).getText();
		
		String tp2 ="Sign in to update your location";
		
			
			
			
		//	assert.assertEquals(tp, tp2);
			
		
		
		
		
		
		
		
			
		
	}

}
