
public class Multi_dimensional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[][]= new int[3][3];
		
		a[0][0]=7;
	    a[0][1]=4;
	    a[0][2]=7;
	  
		
	    a[1][0]=6;
	    a[1][1]=1;
	    a[1][2]=8;
	
	
	    a[2][0]=3;
	    a[2][1]=6;
	    a[2][2]=9;
	    	  	
	    int min=a[0][0];
	
	    
	    for(int i=0;i<a.length;i++)
	    {
	    	for (int j=0;j<a.length;j++) {
	    		System.out.println(a[i][j]);
	    		
	    		
	    		
	    		
	    		if(a[i][j]<min) {
	    			
	    			min=a[i][j];
	    		}
	    		
	    	}
	    	System.out.println("\t");
	    }
	    System.out.println("minimum value is "+min);
	    
	    int h = 0;
	    int b = 0;
	    int k=0;
	    int l = 0;
	    
	    for(k=0;k<a.length;k++) {
	    	for ( l=0;l<a.length;l++) {
	    		
	    		if(a[k][l]==min) {
	    			System.out.println("row is " + k);
	    			System.out.println("column is "+ l);
	    			
	    			h=l;
	    			b=k;
	    					
	    		}
	    		
	    		
	    	}
	    }
	    
	    int maxincloumn = a[h][b];
	    
	    for(int m=0;m<a.length;m++) {
	    	if(a[m][h]>maxincloumn) {
    			
    			maxincloumn=a[m][h];
    			
    			
    		}
	    }
	    System.out.println("Max in row"+k+"and column "+l+"is"+maxincloumn);
		
	}

}
