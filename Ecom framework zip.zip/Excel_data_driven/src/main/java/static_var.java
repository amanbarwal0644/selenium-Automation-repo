
public class static_var {

	
	String name;
	String address;
	String city ="Ludhina";
	
	
	//static 
	
	
static {
		int  i=0;
}


	public  static_var(String a, String b) {
		
		this.name = a;
		this.address =b;
		
		
		System.out.println(this.name);
		System.out.println(this.address);
		System.out.println(this.city);
	//	i=i+1;
		//System.out.println(i);
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		static_var obj = new static_var("Aman","32");
		static_var obj1 = new static_var("Aman2","322");
		static_var obj2 = new static_var("Aman2","322");
		
	
	}

}
