
public class Parent_cons {

	
	
	public Parent_cons() {
		System.out.println("parent constructor");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
