import java.io.IOException;
import java.util.ArrayList;

public class Get_data_from_excel_data_retrieval {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		Excel_data_extraction  get_data = new Excel_data_extraction();
		ArrayList pdata=get_data.data_return("name");
		System.out.println(pdata.get(0));
		System.out.println(pdata.get(1));
		System.out.println(pdata.get(2));
		System.out.println(pdata.get(3));
	
	}

}
