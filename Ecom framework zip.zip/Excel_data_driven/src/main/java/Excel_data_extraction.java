import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_data_extraction {

	
	public static ArrayList data_return(String catch_data) throws IOException {
		
ArrayList a = new ArrayList();
		
		
		
		FileInputStream fis = new  FileInputStream("C://Users//admin//eclipse-workspace//EXCEL WORKSHEET//Workbooknew.xlsx");
		
		XSSFWorkbook book_obj =  new XSSFWorkbook(fis);
		
	int total = 	book_obj.getNumberOfSheets();
	
	System.out.println(total);
	
	for (int i=0;i<total;i++) {
		
		if(book_obj.getSheetName(i).equalsIgnoreCase("Book1")) {
			System.out.println("inside book1");
			
			XSSFSheet sheet = book_obj.getSheetAt(i);
			
	Iterator<Row> rows	=sheet.rowIterator();
	Row first_row = rows.next();
	
	
	
	Iterator<Cell> cell = first_row.cellIterator();
	int k=0;
	int column=0;
	while(cell.hasNext()) {
	Cell value = cell.next();
	
	if(value.getStringCellValue().equalsIgnoreCase("Data2")) {
	
		System.out.println("found at index"+k);
		
		column = k;
	}
	
	k++;
	
	
	}
	
	
	
	while(rows.hasNext()) {
		
		Row r = rows.next();
		String aman  = r.getCell(column).getStringCellValue();
		System.out.println(r.getCell(column).getStringCellValue());
	
		
		if(aman.equals(catch_data)) {
			Iterator<Cell> cello = r.cellIterator();
			System.out.println("hey");
			while(cello.hasNext()) {
				Cell value = cello.next();
				
				a.add(value.getStringCellValue());
			
		}
		}
			
	
		else {
		
System.out.println("helo");

		}
		
		
		
	}
	


	
	
	
	
	
	}

	}
	return a;
		
	}
	
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
}
}
