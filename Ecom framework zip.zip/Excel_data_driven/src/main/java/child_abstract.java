
public class child_abstract extends Parent_abstract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		child_abstract obj = new child_abstract();
		
		obj.color();
		obj.Aircraft_design();
		obj.child_own_method();
		
		//Parent_abstract obj2 = new Parent_abstract();
		
		
		
	}

	
	public void child_own_method() {
		System.out.println("children own method");
	}


	@Override
	public void color() {
		// TODO Auto-generated method stub
		System.out.println("i have customized color according to my company");
	}
	
}
