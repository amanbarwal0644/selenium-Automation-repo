
public class implemets_interface_prac implements Interface_practice,interface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		Interface_practice obj = new implemets_interface_prac();
		
		obj.green();
		obj.yello();
		
		blue();
		
	}

	  public void green() {
		// TODO Auto-generated method stub
		
		System.out.println("test");
	}

	public void yello() {
		// TODO Auto-generated method stub
		
		
		
		
	}
	
	public static void blue() {
		System.out.println("hi");
	}
	
	
			
		

	public void interface2_method() {
		// TODO Auto-generated method stub
		System.out.println("second interface");
	}

	

}

