
public class child extends Abstract{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		child obj = new child();
		obj.go();

		
		
		
		
		
		
	}

	@Override
	public void wait2() {
		// TODO Auto-generated method stub
		System.out.println("wait");
	}
	
	
	public void packages() {
		
	}
	
	
}
