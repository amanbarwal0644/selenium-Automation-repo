import java.util.ArrayList;

public class Amazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	//	455546694
		
		
	int a[]= {4,5,5,5,4,6,6,9,4};
		
		
		
		ArrayList<Integer> b = new ArrayList<Integer>();
		int i;
		
		
		for (i=0;i<a.length;i++) {
			
			int c=0;
			
				
			
			if(!b.contains(a[i])) {
				b.add(a[i]);
				
				
				c++;
				for(int j=i+1;j<a.length;j++) {
				
					if(a[j]==a[i]) {
						c++;
					}
				
					
				}
				System.out.println("number"+a[i]+"repeating"+c+"times");
				
			}
			
			
			
		}
		
		
		
	}

}
