
public interface interface2 {

	
	
	public void interface2_method();
}
