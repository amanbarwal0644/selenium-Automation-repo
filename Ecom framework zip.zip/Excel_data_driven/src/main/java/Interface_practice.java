
public interface Interface_practice {

	
	public int a=9; 
   public void green();
	
	public  void yello();
}
