
public class Practice_java_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	
		int k=1;
		
	/*	for(int i=0;i<=4;i++) {
			
			
			  for(int j=1;j<=4-i;j++)
			  
			  { System.out.print(k); System.out.print("\t"); k++; } System.out.println("");
			 
			
		}
		*/	
		/*	
			for(int  y=1;y<=4;y++) {
				
			
				for(int z=1;z<=y;z++)
				{
					
					
					System.out.print(z);
					System.out.print("\t");
					
			
				}
				System.out.println("");
			}
			
			*/
		int p=1;
		for (int i=1;i<=3;i++) {
			for (int j=1;j<=i;j++) {
				
				
				System.out.print(3*p);
				System.out.print("\t");
				p++;
			}
			System.out.println("");
		}
			
			
		}
		
	}


