
public class Constructor {

	

	public Constructor(int a , int b) {
		
		System.out.println("im in constructor");
	}
	
	
	public void getdata() {
		System.out.println("im in getdata");
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Constructor obj1 = new Constructor(2,4);
		
		
		
	}

}
