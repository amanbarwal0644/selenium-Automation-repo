
public abstract class Abstract {


public void go() {
	System.out.println("go");
	
}

public abstract  void wait2();




}
