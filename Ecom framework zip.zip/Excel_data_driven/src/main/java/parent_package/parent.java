package parent_package;


public class parent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
	}

	public void packages() {
		
	}
	
}
