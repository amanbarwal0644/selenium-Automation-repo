
public class ExceptionDemo  {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		
	
	
	
	try{
	
	//  Block of code to try
	int a=0;
	int b =4;
	int c=b/a;
	}
	
	
	catch(Exception e) {
		
	}
}
}