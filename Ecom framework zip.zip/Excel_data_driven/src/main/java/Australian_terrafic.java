
public class Australian_terrafic implements Centeral_terraifc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Centeral_terraifc obj = new Australian_terrafic();
		
	}

	public void green() {
		// TODO Auto-generated method stub
		System.out.println("im inside green");
	}

	public void red() {
		// TODO Auto-generated method stub
	
		System.out.println("im inside red");
	}

	public void yellow() {
		// TODO Auto-generated method stub
		
		System.out.println("im inside Yellow");
	}
	
	
	
	public void Aus_meth() {
		System.out.println("im  from Autralian method");
	}

}
