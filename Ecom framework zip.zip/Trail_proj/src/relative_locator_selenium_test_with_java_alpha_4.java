

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.openqa.selenium.support.locators.RelativeLocator.*;
public class relative_locator_selenium_test_with_java_alpha_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
		
		WebDriver driver  = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		 WebElement editbox = driver.findElement(By.cssSelector("[class*='form-control']"));
		 
		 // now we are using relative locators
		 
		System.out.println( driver.findElement(with(By.tagName("label")).above(editbox)).getText());
		 

	WebElement dob=	driver.findElement(By.name("bday"));
	
	System.out.println(driver.findElement(with(By.tagName("label")).above(dob)).getText());
	
	WebElement ref_element = driver.findElement(By.xpath("//label[text()='Check me out if you Love IceCreams!']"));
	
System.out.println(ref_element.getText());

driver.findElement(with(By.tagName("input")).toLeftOf(ref_element)).click();

WebElement radiobutton = driver.findElement(By.xpath("//input[@name='inlineRadioOptions']"));

System.out.println(driver.findElement(with(By.tagName("label")).toRightOf(radiobutton)).getText());


	
	}

}
