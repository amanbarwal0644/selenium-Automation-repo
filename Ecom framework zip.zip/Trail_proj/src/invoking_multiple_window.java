import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class invoking_multiple_window {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/angularpractice/");

		driver.switchTo().newWindow(WindowType.TAB);

		driver.get("https://rahulshettyacademy.com/");

		
		 Set<String> id = driver.getWindowHandles();
		  
		  Iterator<String> it = id.iterator(); 
		  String pp_id = it.next(); String
		  child_id = it.next();
		  
		  driver.switchTo().window(child_id);
		  
		 
		String text = driver.findElement(By.xpath("//div[@class='col-md-6 text-left']/h2/span")).getText();

		driver.switchTo().window(pp_id);
		
	WebElement first_name_field = 	driver.findElement(By.name("name"));
	
	first_name_field.sendKeys(text);
	
	File image = first_name_field.getScreenshotAs(OutputType.FILE);
	
	FileUtils.copyFile(image, new File("C:\\Users\\admin\\OneDrive\\Desktop\\ScreenShot\\partial.png"));
	

		// System.out.println(driver.findElement(By.xpath("//div[class='viewsTitle']/h1")).getText());
	
	
	// how to capture height and width of input field for UI/UX validation
	
System.out.println(	first_name_field.getRect().getDimension().getHeight());

System.out.println(first_name_field.getRect().getDimension().getWidth());
	
	

	}

}
