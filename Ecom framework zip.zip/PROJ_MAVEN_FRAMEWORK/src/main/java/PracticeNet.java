import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PracticeNet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
/*
		int number=153;
		
		int remainder, total=0, temp = number;
		
		while (temp!=0) {
			
			remainder =temp%10;
			temp=temp/10;
			
			total =total+remainder*remainder*remainder;
			System.out.println(total);
			
			
		}
		
		if(total==number) {
			System.out.println("this is armstron number");
		}
		else {
			System.out.println("this is not armstron number");
		}
	*/	
		
System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
	
		
		
		
		WebDriver driver =  new FirefoxDriver();
	/*	driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		driver.findElement(By.className("blinkingText")).click();
		
		String id = driver.getWindowHandle();
		
		System.out.println(id);
		
		*/
		
		
		
		    }
		}
	
	
