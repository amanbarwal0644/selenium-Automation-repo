package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.Resources;

import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Extent_reportNG {

	@BeforeTest
public static  ExtentReports report_method_listener_class() {
		
		
		ExtentSparkReporter ESR  = new ExtentSparkReporter(System.getProperty("user.dir")+"//ExtentReports//HTML_CHART_REPORT");
		
		ESR.config().setReportName("error validation report");
		ESR.config().setDocumentTitle("ECOM WEB REPORTS by TESTNG");
		
		
		ExtentReports ER = new ExtentReports();
		ER.attachReporter(ESR);
		ER.setSystemInfo("Tester","Aman Kumar Barwal");
		
		return ER;
		
		
		
		
		
				
		
	}
	

	
}

