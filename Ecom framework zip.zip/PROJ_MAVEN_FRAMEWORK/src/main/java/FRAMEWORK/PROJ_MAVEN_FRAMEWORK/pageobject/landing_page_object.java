package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class landing_page_object extends Abstract_method{
	WebDriver driver;
	
	
	public landing_page_object(WebDriver driver) {
		super(driver);
	this.driver = driver;	
	
	PageFactory.initElements(driver, this);
	
	
	}
	
	
	
//	WebElement email=driver.findElement(By.id("userEmail"));
	//WebElement password = 	driver.findElement(By.id("userPassword"));
	//WebElement submit_button= driver.findElement(By.id("login"));
	
	
	//page factory support page object model 
	
	@FindBy(id = "userEmail")
	WebElement email;
	
	
	
	@FindBy(id = "userPassword")
	WebElement password;
	
	
	@FindBy(id = "login")
	WebElement submit_button;
	
	
	@FindBy(css="[class*=flyInOut]")
	WebElement alert;
	
	@FindBy(css="div[class*=toast-message]")
	WebElement toast;
	
	public Product_catelog login_method(String usremail,String usrpassword) {
		
		email.sendKeys(usremail);
		password.sendKeys(usrpassword);
		submit_button.click();
		
		waiting_for_product_added_to_cart_alert_to_disappear(toast);
		Product_catelog Product_catelog_obj = new Product_catelog(driver);
		return Product_catelog_obj;
		
	}
	
	public String message_alert() {
		waiting_element_to_visiblity_of_webLement(alert);
	String a = 	alert.getText();
	return a;
	}
	
	public void geturl() {
		driver.get("https://rahulshettyacademy.com/client");
	}
	
}
