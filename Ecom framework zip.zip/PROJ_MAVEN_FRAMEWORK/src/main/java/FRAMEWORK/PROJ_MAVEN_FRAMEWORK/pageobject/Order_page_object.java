package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Order_page_object extends Abstract_method{
	WebDriver driver;
	
	
	

	public Order_page_object(WebDriver driver) {
		super(driver);
	this.driver = driver;	
	
	PageFactory.initElements(driver, this);
	
	
	}
	
	
	
	
	@FindBy(css="tr[class='ng-star-inserted'] td:nth-child(3)")
	List<WebElement> oder_his_list; 
	
	public boolean Order_prsnt_in_OrderHistory_or_not() {
		
		Boolean get_order_match_result=   oder_his_list.stream().anyMatch(cart->cart.getText().equalsIgnoreCase("IPHONE 13 PRO"));
	
		return get_order_match_result;
	}
	
}
