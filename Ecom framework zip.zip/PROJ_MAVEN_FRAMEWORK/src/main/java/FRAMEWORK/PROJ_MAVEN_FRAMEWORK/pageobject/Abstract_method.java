package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Abstract_method {

	WebDriver driver;
	


	
	
	public  Abstract_method(WebDriver driver) {
		this.driver =  driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(css="button[routerlink*='myorders']")
	WebElement order_tab;
	
	
	
	
	public void waiting_element_to_appear(By findby) {
		
		 WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		 w.until(ExpectedConditions.visibilityOfElementLocated(findby));
	}
	
	
	public void waiting_element_to_disappear(By findby) {
		
		 WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));

		 w.until(ExpectedConditions.invisibilityOfElementLocated(findby));
	}
	
	public void waiting_element_to_visiblity_of_webLement(WebElement ele) {
		
		 WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));

		 w.until(ExpectedConditions.visibilityOf(ele));
	}
	
	
	
	public void waiting_for_product_added_to_cart_alert_to_disappear(WebElement toast) {
	
		 WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));

		 w.until(ExpectedConditions.invisibilityOf(toast));
		
		
	}
	
	
	public Order_page_object click_on_order_header() {
		
		order_tab.click();
		Order_page_object  order_page = new Order_page_object(driver);
		return order_page;
		
	}
	
	
	
}
