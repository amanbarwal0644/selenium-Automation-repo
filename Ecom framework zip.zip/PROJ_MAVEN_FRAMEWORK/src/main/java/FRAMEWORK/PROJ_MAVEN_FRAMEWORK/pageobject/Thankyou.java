package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Thankyou extends Abstract_method {
	WebDriver driver;
	public Thankyou(WebDriver driver) {
		super(driver);
	this.driver = driver;	
	
	PageFactory.initElements(driver, this);
	}
	@FindBy(css =".hero-primary")
	WebElement confirm;
	
	By confirm_b = By.cssSelector(".hero-primary");
	
	public boolean thankyoupage() {
		
		waiting_element_to_appear(confirm_b);
		 String confirm_message = confirm.getText();
		 boolean messge = confirm_message.equalsIgnoreCase("THANKYOU FOR THE ORDER.");
		 return messge;
			
		//	driver.close();
	}
	
	@FindBy(xpath="(//button[@class='btn btn-custom'])[4]")
	WebElement Signout;
	
	public void clickOnSignout()
	{
		Signout.click();
	}

}
