package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Product_catelog extends Abstract_method {
	WebDriver driver;
	public Product_catelog(WebDriver driver) {
		super(driver);
	this.driver = driver;	
	
	PageFactory.initElements(driver, this);
	}
	
	
	
	
	@FindBy(id = "login")
	WebElement submit_button;
	
	
	
	
	
	@FindBy(css=".mb-3")
	List<WebElement>  list_of_products; 

	By wait_for_toast = By.cssSelector("#toast-container");
	
	By invisible_toast = By.cssSelector(".ng-animating");
	
	





	public List<WebElement> product_list_actn() {
		waiting_element_to_appear(wait_for_toast);
		return list_of_products;
	}

	
	public WebElement get_product_by_name(String product_name) {
		
		WebElement rf=	product_list_actn().stream().filter(product->product.findElement(By.cssSelector("b")).getText().equals(product_name)).findFirst().orElse(null);
		System.out.println(rf.getText());
		return rf;
	}
	
	
	public cart add_to_Cart(String product_name) {
		WebElement rf = get_product_by_name(product_name);
		rf.findElement(By.cssSelector(".card-body button:last-of-type")).click();
		waiting_element_to_appear(wait_for_toast);
		waiting_element_to_disappear(invisible_toast);
		
		cart cart1 =  new cart(driver);
		return cart1;
	}
	
		


		
	
		
	
}
