package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class cart extends Abstract_method {
	WebDriver driver;
	public cart(WebDriver driver) {
		super(driver);
	this.driver = driver;	
	
	PageFactory.initElements(driver, this);
	}
	
	@FindBy(css = "button[routerlink*='/dashboard/cart']")
	WebElement cart_button ;
	
	@FindBy(css =".cartSection h3")
	List<WebElement> cart_oders;
	
	
	By wait_for_checkout_btn = By.cssSelector(".totalRow button");
	
	
@FindBy(css =".totalRow button")
WebElement check;


	
	
	public void cart_button() {
		cart_button.click();
		
	}
	
		public List<WebElement> cart_orders() {
		
			return cart_oders;
		}
		
		
		public boolean prdct_present_in_cart_or_not(String product) {
			
			Boolean get_match_result=   cart_orders().stream().anyMatch(cart->cart.getText().equalsIgnoreCase(product));
		
			return get_match_result;
		}
		
		public payment checkout() {
			
			
			waiting_element_to_appear(wait_for_checkout_btn);
			 JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("arguments[0].click();", check);
			 
			 payment payment = new payment(driver);
			 return payment;
		}
		
		

}
