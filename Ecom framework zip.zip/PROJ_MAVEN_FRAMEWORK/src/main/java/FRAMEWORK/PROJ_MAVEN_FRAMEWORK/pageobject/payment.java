package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class payment extends Abstract_method{

	WebDriver driver;
	public payment(WebDriver driver) {
		super(driver);
	this.driver = driver;	
	
	PageFactory.initElements(driver, this);
	
}
	
	
	@FindBy(css = "input[placeholder='Select Country']")
	WebElement country_field;

	@FindBy(xpath = "(//button[contains(@class,'ta-item')])[2]")
	WebElement country ;

	
	By country_f = By.cssSelector(".ta-item");

	@FindBy(css=".action__submit ")
	WebElement place_order;

	
	public void select_country(String which_country) {
		// TODO Auto-generated method stub
		 Actions A= new Actions(driver);
		  
		  A.sendKeys(country_field, which_country).build().perform();
			waiting_element_to_appear(country_f);
		  
		  country.click();
	}
	
	public Thankyou place_order() {
		waiting_element_to_visiblity_of_webLement(place_order);
		place_order.click();
		
		Thankyou thn = new Thankyou(driver);
		return thn;
	}
	
}
