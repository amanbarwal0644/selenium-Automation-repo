import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class test12345 {

	public static void main(String[] args, Object String) {
		// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
	
		
		
		
		WebDriver driver =  new FirefoxDriver();
		Set<String> s = driver.getWindowHandles();
		Set<String>g =driver.getWindowHandles();
		
		Iterator<String> move = g.iterator();
		String child_id = move.next();
		
		
		driver.switchTo().window(child_id);
		
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(3));
		
		driver.get("https://www.amazon.in/ap/register?openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fref%3Drhf_sign_in&openid.assoc_handle=inflex");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3000));
		
		driver.findElement(By.id("ap_customer_name")).sendKeys("Aman");
		driver.findElement(By.id("ap_phone_number")).sendKeys("123456789");
		driver.findElement(By.id("ap_password")).sendKeys("Aman#5123");
		
		
	
		
		wait.until(ExpectedConditions.elementToBeClickable(By.id("continue")));
		
		driver.findElement(By.id("continue")).click();
		
		
		driver.get("https://www.amazon.in/ref=navm_hdr_logo");
		
		

		
		System.out.println(driver.findElement(By.tagName("a")));
		
	String tp = 	driver.findElement(By.id("glow-ingress-single-line")).getText();
	
	String tp2 ="Sign in to update your location";
	
		
		
		
	
Assert.assertEquals(tp, tp2);
	



 
	
	Assert.assertEquals(driver.findElement(By.tagName("p")).getText(),"You are successfully logged in.");
		
	
	
	
			
		
		

	

	
	
	}
	}


