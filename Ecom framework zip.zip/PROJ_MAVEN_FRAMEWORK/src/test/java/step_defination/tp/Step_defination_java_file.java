package step_defination.tp;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent.BaseTestClass;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.Product_catelog;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.Thankyou;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.cart;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.landing_page_object;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.payment;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Step_defination_java_file extends BaseTestClass {

	public landing_page_object Home_page_object;
	
	public Product_catelog Product_catelog_obj;
	public cart cart_obj;
	public payment pay;
	public Thankyou thn;
	
	@Given ("Land on ecom page")
	public void land_on_ecom_page() throws IOException {
		 
		    // Write code here that turns the phrase above into concrete actions
		   
		Home_page_object=launch_browser();
		
	}
	
	//Given login with user email <Emailname> and password <password>
	
	
	@Given("^login with user email (.+) and password (.+)$")
	public void login_with_email_pass(String email, String password) {
		
	 Product_catelog_obj = obj.login_method(email,password);
		
	}
	
	// When product is added tp cart <PRD_NM>
	 
	 @When("^product is added tp cart (.+)$")
	 public void add_to_cart(String PRD_NM) {
		 List<WebElement> list_products = Product_catelog_obj.product_list_actn();
		 Product_catelog_obj.get_product_by_name(PRD_NM);	
		cart_obj = Product_catelog_obj.add_to_Cart(PRD_NM);
		cart_obj.cart_button();
		
	 }
	 
	 
	  //And checkout and verify product name in checkout page <PRD_NM>
	  
	  @And("^checkout and verify product name in checkout page (.+)$")
	  public void checkout_and_verify(String PRD_NM) {
		  
		  
		  boolean math = cart_obj.prdct_present_in_cart_or_not(PRD_NM);
			Assert.assertFalse(math);		
			payment pay = cart_obj.checkout();
			String which_country = "india";
			pay.select_country(which_country);
			Thankyou thn = pay.place_order();
			boolean ao = thn.thankyoupage();
			Assert.assertTrue(ao);
	  }
	  
	//  Then Thankyou message displayed<Message> 
	  
	  @Then("message displayed")
	  public void Thankyou() {
	
		  
		
			thn.clickOnSignout();
	  }
	 
	 
	 
	
}
