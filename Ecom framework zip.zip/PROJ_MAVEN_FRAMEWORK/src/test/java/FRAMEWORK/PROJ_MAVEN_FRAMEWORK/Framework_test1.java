package FRAMEWORK.PROJ_MAVEN_FRAMEWORK;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent.BaseTestClass;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.Order_page_object;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.Product_catelog;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.Thankyou;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.cart;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.landing_page_object;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.payment;



public class Framework_test1 extends BaseTestClass{

	//String email = "framework@yopmail.com";
	//String password = "BaRWAL#5";
	

	@Test(groups= {"grouping"},dataProvider = "data_provider")
	public void framework_test(HashMap<String,String>input) throws IOException {
		// TODO Auto-generated method stub

		
		
		
		
		
		
		//landing_page_object obj =launch_browser();
		Product_catelog Product_catelog_obj = obj.login_method(input.get("email"), input.get("password"));
	
		
	//	driver.manage().window().maximize();
	//	String a = driver.findElement(By.cssSelector(".mb-3 div div h5")).getText();
	//	System.out.println(a);
		List<WebElement> list_products = Product_catelog_obj.product_list_actn();	
	//	String PRD_NM= "IPHONE 13 PRO";
		Product_catelog_obj.get_product_by_name(input.get("PRD_NM"));	
		
		
		
		cart cart = Product_catelog_obj.add_to_Cart(input.get("PRD_NM"));
		cart.cart_button();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean math = cart.prdct_present_in_cart_or_not(input.get("PRD_NM"));
		Assert.assertTrue(math);		
		payment pay = cart.checkout();
		String which_country = "india";
		pay.select_country(which_country);
		Thankyou thn = pay.place_order();
		boolean ao = thn.thankyoupage();
		Assert.assertTrue(ao);
		thn.clickOnSignout();
		
		
		
		
		// check oder placed is in order list after placing order
		
	
		
		
		
	 WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
	  
	
	 
	
	
		/*
		 * re.findElement(By.cssSelector(".card-body button:last-of-type")).click();
		 * 
		 * w.until(ExpectedConditions.visibilityOfElementLocated(By.
		 * cssSelector("#toast-container")));
		 * 
		 * 
		 * w.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(
		 * ".ng-animating")));
		 * 
		 */
	  
	 
	  
	  
	  
	  
	
	//  List<WebElement>cart_order = driver.findElements(By.cssSelector(".cartSection h3"));
	  
	
	/*
	 * System.out.println(get_match_result);
	 * 
	 * Assert.assertTrue(get_match_result);
	 */
	//  w.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".totalRow button")));
	  
	 
		/*
		 * js.executeScript("window.scrollBy(0,8000)", "");
		 * 
		 * 
		 */
	 
	 
	  
	  
	  
	  
	  
	  

	}

	/*
	@Test(dependsOnMethods= {"framework_test"})
	public void order_history_verify() throws InterruptedException {
		
	//	String email = "framework@yopmail.com";
	//	String password = "BaRWAL#5";
		//Zara code 3
		
		
		Product_catelog Product_catelog_obj = obj.login_method(email, password);
		
		Thread.sleep(3000);
		
		Order_page_object order_page=Product_catelog_obj.click_on_order_header();
		
		Assert.assertFalse(order_page.Order_prsnt_in_OrderHistory_or_not());
		
	}
	*/
	
	
	
	
	@DataProvider
	public Object[][] data_provider() throws IOException {
		
		
		/*
		 * HashMap<String,String> Map = new HashMap<String,String>();
		 * 
		 * Map.put("email" , "Ecost@yopmail.com"); Map.put("password","BaRWAL#5");
		 * Map.put("PRD_NM","ADIDAS ORIGINAL");
		 * 
		 * HashMap<String,String> Map1 = new HashMap<String,String>();
		 * 
		 * Map1.put("email" , "Ecost@yopmail.com"); Map1.put("password","BaRWAL#5");
		 * Map1.put("PRD_NM","ADIDAS ORIGINAL"); Map1.put("email" ,
		 * "framework@yopmail.com"); Map1.put("password","BaRWAL#5");
		 * Map1.put("PRD_NM","IPHONE 13 PRO");
		 */
		
		List<HashMap<String,String>> data = convert_json_data_to_HashMap(System.getProperty("user.dir")+"\\src\\test\\java\\Json_file_package\\Json_data.json");
		
		return new Object[][] {{data.get(0)},{data.get(1)}};
		
		
/*		
		
	Object[][] i_will_provide_data = 	new Object[2][3];
	
	i_will_provide_data[0][0]="Ecost@yopmail.com";
	i_will_provide_data[0][1]="BaRWAL#5";
	i_will_provide_data[0][2]="ADIDAS ORIGINAL";
	
	i_will_provide_data[1][0]="framework@yopmail.com";
	i_will_provide_data[1][1]="BaRWAL#5";
	i_will_provide_data[1][2]="IPHONE 13 PRO";
	
	
	return i_will_provide_data;
	*/	
	}
	
	
}
