package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry_failed_test implements IRetryAnalyzer {

	int count=0;
	int max=2;
	
	@Override
	public boolean retry(ITestResult result) {
		// TODO Auto-generated method stub
		
		if(count<max)
		{
			count++;
			return true;
		}
		return false;
	}

}
