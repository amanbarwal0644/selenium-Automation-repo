package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.Resources.Extent_reportNG;

public class Listener  extends BaseTestClass implements ITestListener {

	
	
	ExtentReports ER=Extent_reportNG.report_method_listener_class();
	ExtentTest test;
	String image_path;
	
	ThreadLocal TL= new ThreadLocal();

	
	
	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		
		//ITestListener.super.onTestStart(result);
		test = ER.createTest(result.getMethod().getMethodName());
		
		TL.set(test);
		
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSuccess(result);
		
	test.log(Status.PASS, result.getMethod().getMethodName()+"has been passed");
	
	
	}

	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailure(result);
		
		
		test.log(Status.FAIL, result.getThrowable()+"has been passed");
		//take screenshot
		
		String curr_method_exe_name = result.getMethod().getMethodName();
		
		try {
			driver = (WebDriver) result.getTestClass().getRealClass().getField("driver").get(result.getInstance());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
		
		try {
			image_path = Take_screenshot(curr_method_exe_name,driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//attach screen shot
		
		test.addScreenCaptureFromPath(image_path);
		
		
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSkipped(result);
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedWithTimeout(result);
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		ITestListener.super.onStart(context);
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		ITestListener.super.onFinish(context);
		
		ER.flush();
	}
	
	

	
	
}
