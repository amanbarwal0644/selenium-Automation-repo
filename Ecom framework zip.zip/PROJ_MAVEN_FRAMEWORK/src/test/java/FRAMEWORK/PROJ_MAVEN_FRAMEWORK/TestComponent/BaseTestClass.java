package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.landing_page_object;

public class BaseTestClass {

	
	public WebDriver driver ;
	public landing_page_object obj;
	public Properties pro;
	public WebDriver initializebrowser() throws IOException {
		
		
		 pro =  new Properties();
		FileInputStream streamobj = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\FRAMEWORK\\PROJ_MAVEN_FRAMEWORK\\Resources\\GlobalData.properties");
		pro.load(streamobj);
		
		String type_of_browser = pro.getProperty("browser");
		
		if(type_of_browser.equalsIgnoreCase("Chrome")) {
			

			//System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
			 driver =  new ChromeDriver();
			 driver.manage().window().maximize();
			 
			
			
		}
		else if(type_of_browser.equalsIgnoreCase("firefox")){
			
			//System.setProperty("webdriver.firefox.driver", "C:\\Users\\admin\\Selenium_browser_driver\\geckodriver.exe");
			 driver =  new FirefoxDriver();
			
		}
		else if(type_of_browser.equalsIgnoreCase("edge")) {
			
			
			System.setProperty("webdriver.msedge.driver", "C:\\Users\\admin\\Selenium_browser_driver\\msedgedriver.exe");
		 driver =  new FirefoxDriver();
			
		}
		
		return driver;
		
		
	
	}
	
	
	public List<HashMap<String, String>> convert_json_data_to_HashMap(String filepath) throws IOException {
		
		// step1 convert json data to string
		
		
		String JsonContent = FileUtils.readFileToString(new File(filepath));
		//, StandardCharsets.UTF_8
		//step2 convert that to hashmap now
		
		ObjectMapper map_string_to_hashmap = new ObjectMapper();
		
		//List<HashMap<String,String>> data = map_string_to_hashmap.readValue(JsonContent, new TypeReference<List<HashMap<String,String>>>);
	
	List<HashMap<String,String>> data =  map_string_to_hashmap.readValue(JsonContent, new TypeReference<List<HashMap<String,String>>>(){
	});
	return data;
	
}

	

	public String Take_screenshot(String aman, WebDriver driver) throws IOException {
		
		TakesScreenshot TS = (TakesScreenshot)driver;
		
		File sc1 = TS.getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(sc1, new File(System.getProperty("user.dir")+"//report//"+aman+  ".png"));
		
		
		return System.getProperty("user.dir")+"//report//"+aman+  ".png";
		
		
	}
	
	
	
	
	@BeforeTest(alwaysRun =true)
	 public landing_page_object launch_browser() throws IOException {
		 driver = initializebrowser();
		 //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		  obj	=new landing_page_object(driver);
		 obj.geturl();
		 return obj;
		 
	 }
	
	
	
		/*
		  @AfterTest public void teardown() { 
			  try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  
		  driver.close();
		   }
		 */
}
