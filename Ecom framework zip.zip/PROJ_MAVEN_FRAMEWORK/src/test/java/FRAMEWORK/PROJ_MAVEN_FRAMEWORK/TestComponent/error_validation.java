package FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.Product_catelog;
import FRAMEWORK.PROJ_MAVEN_FRAMEWORK.pageobject.cart;

public class error_validation extends BaseTestClass {

	
	
	String email = "test@yopmail.com";
	String  password = "123";

	@Test(retryAnalyzer=FRAMEWORK.PROJ_MAVEN_FRAMEWORK.TestComponent.Retry_failed_test.class)
public void triggeralert_pswd_incorrect () {
		
		
		
		
	 obj.login_method(email, password);
	
	Assert.assertEquals("Incorrect email or passwor.", obj.message_alert());
	
	
}
/*	
	@Test
	public void order_error_validation() throws IOException {
		// TODO Auto-generated method stub

		
		
		
		
		
		
		String email = "framewor@yopmail.com";
		String password = "BaRWAL#5";
		//landing_page_object obj =launch_browser();
		Product_catelog Product_catelog_obj = obj.login_method(email, password);
	//	driver.manage().window().maximize();
	//	String a = driver.findElement(By.cssSelector(".mb-3 div div h5")).getText();
	//	System.out.println(a);
		List<WebElement> list_products = Product_catelog_obj.product_list_actn();	
		String PRD_NM= "IPHONE 13 PRO";
		Product_catelog_obj.get_product_by_name(PRD_NM);	
		cart cart = Product_catelog_obj.add_to_Cart(PRD_NM);
		cart.cart_button();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean math = cart.prdct_present_in_cart_or_not();
		Assert.assertTrue(math);		
		
	
	
	
	
	}*/
}
