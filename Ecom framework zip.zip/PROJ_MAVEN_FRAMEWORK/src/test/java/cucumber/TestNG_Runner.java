package cucumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src\\test\\java\\cucumber", glue="step_defination.tp", 
monochrome=true,plugin= {"html:target/test_ng_runner_report.html"})
public class TestNG_Runner extends AbstractTestNGCucumberTests {

	
	
	
}
