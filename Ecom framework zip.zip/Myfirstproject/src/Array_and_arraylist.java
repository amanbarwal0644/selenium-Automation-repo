
public class Array_and_arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//First way memory allocation at the starting
		
/*String[] jokey = {"dhoop","vitamin"};

for(String e:jokey) {
	System.out.println(e);
	
}

//second array type declaration

String[] doodle = new String[5];

doodle[0]="rumi";
doodle[1]="google";
doodle[2]="hcl0";
for(String j:doodle)
{
System.out.println(j);
}


//third way

String tanuj[] = new String[6];

tanuj[0]="juggad";

System.out.println(tanuj[0]);

*/
		
		
		// first way of declaring an array
		
	/*
		String[] aman = {"yahoo","google","microsoft","wipro"};
		
		for(String v : aman)
		{
			
			System.out.println(v);
		}
		
	// same above aaray declare in another way
		
		String Amank[] = {"another","way","of","declaring","the ","array"};
		
		for(String h :Amank ) {
			System.out.println(h);
		}
	
		
		// Second major way of declaring an array
		
		String[] Barwal = new String[5];
		
		Barwal[0] = "high";
		Barwal[1]="school";
		Barwal[2] = "dot square";
		
		for(String j : Barwal) {
			System.out.println(j);
				
		}
		
		//another way of declaring this above array
		
		String joker[] = new String[5];
		
		joker[0]="ffffff";
		joker[1]="kkkkkk";
		joker[2]="hhhhhh";
		
		for(String o : joker) {
			System.out.println(o);
		}
		
		
		
		*/
	
		//normal  for loop
		
		String unit[] = new String[5];
		unit[0]="unit1";
		unit[1]="unit2";
		unit[2]="unit3";
		unit[3]="unit4";
		unit[4]="unit5";
		for(int i=0;i<5;i++) {
			System.out.println(unit[i]);
		}
		
		try{
			
			//  Block of code to try
			int a=0;
			int b =4;
			int c=b/a;
			}
			
			
			catch(Exception e) {
				
				System.out.println("hi");
			}
	}
	

	}


