import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class cssSelector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//invoking the browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		//step1 first find the location where you want to perform the operations
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.findElement(By.cssSelector("input#inputUsername")).sendKeys("css selector");
		driver.findElement(By.cssSelector("input[placeholder = 'Password']")).sendKeys("barwal");
		//driver.findElement(By.cssSelector("button.submit")).click();
//another of defining css selector for a class is .classname
driver.findElement(By.cssSelector(".submit")).click();
try {
	Thread.sleep(5000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

String inreturn= driver.findElement(By.cssSelector(".error")).getText();
System.out.println(inreturn);
	
	driver.findElement(By.linkText("Forgot your password?")).click();
	//through CSS selector
	/*
	driver.findElement(By.cssSelector("input[PLaceholder = 'Name']")).sendKeys("aman");
	driver.findElement(By.cssSelector("input[Placeholder = 'Email']")).sendKeys("amanbarwal.ab@gmail.com");
	driver.findElement(By.cssSelector("input[Placeholder= 'Phone Number']")).sendKeys("7986073175");
	driver.findElement(By.cssSelector(("button.reset-pwd-btn"))).click();
	String holdpassword = driver.findElement(By.className("infoMsg")).getText();
	System.out.println(holdpassword);
	*/
	
	//Through Xpath
	
/*  driver.findElement(By.xpath("//input[@placeholder = 'Name']")).sendKeys("Aman");
	driver.findElement(By.xpath("//input[@placeholder = 'Email']")).sendKeys("amanbarwal.ab@gmail.com");
	driver.findElement(By.xpath("//input[@placeholder = 'Phone Number']")).sendKeys("7986073175");
	driver.findElement(By.xpath("//button[@class='reset-pwd-btn']")).click();
	String holdpassword2 = driver.findElement(By.xpath("//p[@class = 'infoMsg']")).getText();
	System.out.println(holdpassword2);
	*/
	
	//through Xpath indexing method 
	
	driver.findElement(By.xpath("//input[@type='text'][1]")).sendKeys("Aman kumar barwal");
	
	driver.findElement(By.xpath("//input[@type='text'][2]")).sendKeys("amanbarwal.ab@gmail.com");
	driver.findElement(By.xpath("//input[@type='text'][3]")).sendKeys("7986073175");
	}
	

}
