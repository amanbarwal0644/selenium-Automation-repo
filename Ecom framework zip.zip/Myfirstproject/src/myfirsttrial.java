import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class myfirsttrial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//for chrome browser 
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
	
	//for firefox driver
	//System.setProperty("webdriver.gecko.driver", "C:\\Users\\admin\\Selenium_browser_driver\\geckodriver.exe");
	/*ChromeDriver driver = new ChromeDriver();
	driver.get("https://ems.dotsquares.com/");
	driver.close();
	*/
	
/*
 * WebDriver driver2 = new ChromeDriver();
 
try {
	Thread.sleep(2000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
driver2.get("https://rahulshettyacademy.com/");


System.out.println(driver2.getTitle());
System.out.println(driver2.getCurrentUrl());

driver2.close();
*/
/*
WebDriver driver1 =new FirefoxDriver();
driver1.get("https://rahulshettyacademy.com/");

try {
	Thread.sleep(2000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
driver1.quit();


System.setProperty("webdriver.edge.driver", "C:\\Users\\admin\\Selenium_browser_driver\\msedgedriver.exe");
WebDriver driver3  = new EdgeDriver();
driver3.get("https://rahulshettyacademy.com/");

try {
	Thread.sleep(2000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
System.out.println(driver3.getTitle());
driver3.close();

int num =5;

System.out.println(num+"value");
*/
//Array declaration
/*
String[] aman = new String[5];
aman[0] = "this";
aman[1]="is";
aman[2]="string";
aman[3]="array";

for (int i=0;i<aman.length;i++)
{
	System.out.println(aman[i]);
}


for(String s:aman)
{
	System.out.println(s);
}

	

String[] stringarray = {"this","is","string","array"};

for (int j= 0;j<stringarray.length;j++)
{
	System.out.println(stringarray[j]);
}



//String[] a = new String[5];

ArrayList<String> a = new ArrayList<String>();

a.add("aman");
a.add("kumar");
a.add("barwal");
a.add("rohit");

for(String s:a) {
	

System.out.println(s);

}
*/

String h= "doodle 'is' google";
//String o = h.trim();
//System.out.println(h.trim());
String[] l=h.split("'");
for(String f:l)
{
	System.out.println(f.trim());
}




	}
	
	

}
