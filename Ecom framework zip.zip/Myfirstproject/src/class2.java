
public class class2 {

public void barwal() {
	System.out.println("am from class2");
}


public static void another() {
	System.out.println("this is another staic method from class2");
}
}
