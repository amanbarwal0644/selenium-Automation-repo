
public class basic_java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		basic_java ab= new basic_java();
		class2 boy = new class2();
		boy.barwal();
		ab.Aman();
		
		
		school();
	
	}

	public void Aman() {
		//return "am coming from outside of main calss";
		System.out.println("am from basic_java class");
	}
	
	
	public static void school() {
		System.out.println("children valley public school");
	}
}
