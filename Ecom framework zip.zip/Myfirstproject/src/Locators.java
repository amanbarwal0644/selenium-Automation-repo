import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//invoking the browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
/*		//step1 first find the location where you want to perform the operations
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.findElement(By.id("inputUsername")).sendKeys("Aman");
		
		driver.findElement(By.name("inputPassword")).sendKeys("aman kumar");
		driver.findElement(By.className("submit")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(driver.findElement(By.className("error")).getText());
	*/
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.findElement(By.cssSelector("input[id= 'inputUsername']")).sendKeys("aman");		
		driver.findElement(By.xpath("//input[@placeholder = 'Password']")).sendKeys("barwal");
		driver.findElement(By.className("submit")).click();
		
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		System.out.println(driver.findElement(By.cssSelector(".error")).getText());
		
		driver.findElement(By.linkText("Forgot your password?")).click();
		
		driver.findElement(By.xpath("//input[@placeholder = 'Name']")).sendKeys("Rahul");
		driver.findElement(By.cssSelector("input[Placeholder = 'Email']")).sendKeys("amanbarwal.ab@gmail.com");
		driver.findElement(By.xpath("//input[@type = 'text'][3]")).sendKeys("7986073175");
		
		driver.findElement(By.xpath("//Form/input[3]")).clear();
		
		driver.findElement(By.xpath("//Form/input[3]")).sendKeys("7986073176");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.findElement(By.cssSelector("button[class *='reset']")).click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String password_info= driver.findElement(By.xpath("//p[@class= 'infoMsg']")).getText();
		
		System.out.println(password_info);
		
		driver.findElement(By.cssSelector("input[type = 'text']:nth-child(5)")).clear();
		
String[] aman = password_info.split("password");

for(int i =0;i<aman.length;i++) {

	System.out.println(aman[i].trim());
}

	
		driver.findElement(By.cssSelector("button[class*=go-to]")).click();
		driver.findElement(By.cssSelector("input[id= 'inputUsername']")).sendKeys("Rahul");		
		driver.findElement(By.xpath("//input[@placeholder = 'Password']")).sendKeys("rahulshettyacademy");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		driver.findElement(By.id("chkboxOne")).click();
		driver.findElement(By.cssSelector("input[id*='chkboxT']")).click();
	//river.findElement(By.xpath("//input[contains(@id,'chkboxT')]")).clear();
		driver.findElement(By.xpath("//input[contains(@id,'chkboxT')]")).click();
		driver.findElement(By.cssSelector("input[id*=chkboxT]")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		driver.findElement(By.className("submit")).click();

		
	}

}
