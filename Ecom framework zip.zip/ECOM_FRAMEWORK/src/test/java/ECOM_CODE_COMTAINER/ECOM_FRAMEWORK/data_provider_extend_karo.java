package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import org.testng.annotations.Test;

	
	public class data_provider_extend_karo extends Data_provider_to_function {
		@Test(dataProvider="login", dataProviderClass= Data_provider_to_function.class)
		public void get_data_frm_dataprovider(String usrnm, String pswd) {
			
			System.out.println(usrnm+pswd);
			System.out.println();
		}
}
