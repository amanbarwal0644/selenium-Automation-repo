package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import ECOM_CODE_page_objects.Check_out_page;
import ECOM_CODE_page_objects.Product_listing;
import ECOM_CODE_page_objects.Thankyou_page;
import ECOM_CODE_page_objects.cart;
import ECOM_CODE_page_objects.login_page;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Error_validation extends Browser_initialization_and_base_test{

	@Test
	public void login_error_validation() {
		// TODO Auto-generated method stub

		
		/*
		 * Browser_initialization browser_invoke_obj = new Browser_initialization();
		 * browser_invoke_obj.browser_details();
		 */
		
		// Invokation of browser
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4000));

		String product_to_add = "ZARA COAT 3";

		// hitting url

		

		// Maximize window
		driver.manage().window().maximize();

		login_page login_page = new login_page(driver);
		login_page.hit_login_url_method();
		login_page.login_to_home_page("JOHNDOEXYZ@yopmail.com", "BaRWAL#5");
	   login_page.get_error_message();
		Assert.assertEquals("Incorrect email or password..",login_page.get_error_message());
	
		
	}
	
	
	
		

}
