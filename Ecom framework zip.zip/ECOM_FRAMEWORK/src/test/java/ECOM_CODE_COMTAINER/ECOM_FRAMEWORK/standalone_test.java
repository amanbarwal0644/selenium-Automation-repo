package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import ECOM_CODE_page_objects.Check_out_page;
import ECOM_CODE_page_objects.Product_listing;
import ECOM_CODE_page_objects.Thankyou_page;
import ECOM_CODE_page_objects.cart;
import ECOM_CODE_page_objects.login_page;
import io.github.bonigarcia.wdm.WebDriverManager;

public class standalone_test extends Browser_initialization_and_base_test{

	@Test
	public void validation() {
		// TODO Auto-generated method stub

		
		/*
		 * Browser_initialization browser_invoke_obj = new Browser_initialization();
		 * browser_invoke_obj.browser_details();
		 */
		
		// Invokation of browser
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4000));

		String product_to_add = "ADIDAS ORIGINAL";
		

	

		

		// Maximize window
		driver.manage().window().maximize();

		login_page login_page = new login_page(driver);
		login_page.hit_login_url_method();
		Product_listing	Product_listing_object=login_page.login_to_home_page("JOHNDOE@yopmail.com", "BaRWAL#5");
	
		
	
		Product_listing_object.add_item_to_cart(product_to_add);
	
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		
		cart cart_obj =Product_listing_object.go_to_cart_page();
		
		
		Boolean match = cart_obj.verify_cart_product(product_to_add);
		
		Assert.assertTrue(match);
	
		Check_out_page check_out_page_obj=cart_obj.click_checkout_button();
		
		Thankyou_page thankyou_page_object=check_out_page_obj.select_country("india");
		

		String confirm_message = thankyou_page_object.get_thankyou_message();
		
		
		
		Assert.assertTrue(confirm_message.equalsIgnoreCase("Thankyou for the order."));
		
		driver.close();
		
	}
	
	
	@Test
	public void validation_second() {
		// TODO Auto-generated method stub

		
		/*
		 * Browser_initialization browser_invoke_obj = new Browser_initialization();
		 * browser_invoke_obj.browser_details();
		 */
		
		// Invokation of browser
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4000));

		String product_to_add = "ZARA COAT 3";
		

	

		

		// Maximize window
		driver.manage().window().maximize();

		login_page login_page = new login_page(driver);
		login_page.hit_login_url_method();
		Product_listing	Product_listing_object=login_page.login_to_home_page("JOHNDOE@yopmail.com", "BaRWAL#5");
	
		
	
		Product_listing_object.add_item_to_cart(product_to_add);
	
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		
		cart cart_obj =Product_listing_object.go_to_cart_page();
		
		
		Boolean match = cart_obj.verify_cart_product(product_to_add);
		
		Assert.assertTrue(match);
	
		Check_out_page check_out_page_obj=cart_obj.click_checkout_button();
		
		Thankyou_page thankyou_page_object=check_out_page_obj.select_country("india");
		

		String confirm_message = thankyou_page_object.get_thankyou_message();
		
		
		
		Assert.assertTrue(confirm_message.equalsIgnoreCase("Thankyou for the order."));
		
		driver.close();
		
	}


}
