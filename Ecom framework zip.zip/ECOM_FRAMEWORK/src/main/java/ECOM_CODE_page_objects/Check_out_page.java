package ECOM_CODE_page_objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Check_out_page extends Reuseable_Methods {


	WebDriver driver;
	
	
	public Check_out_page(WebDriver driver) {
		super(driver);
		this.driver=driver ;
		PageFactory.initElements(driver, this);
		
	}
	//enter  country name
	@FindBy(css="input[placeholder='Select Country']")
	WebElement Enter_country;
	
	// wait for country list to appear after entering contry.
	
	By country_list_appear = By.cssSelector("section[class*='ta-results list-group ng-star-inserted']");
	
	//click on country name
	@FindBy(css="section[class*='ta-results list-group ng-star-inserted'] button:nth-of-type(2)")
	WebElement Select_country;
	
	// click on place order button
	
	@FindBy(css=".action__submit")
	WebElement Place_order;
	
	
	
	public Thankyou_page select_country(String country_name) {
		
		Actions a = new Actions(driver);
		a.sendKeys(Enter_country,country_name).build().perform();
		
		wait_element_to_appear(country_list_appear);
		Select_country.click();
		Place_order.click();
		
		Thankyou_page thankyou_page_object = new Thankyou_page(driver);
		return thankyou_page_object;
		
		
		
	}
	
}
