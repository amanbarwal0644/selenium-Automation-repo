package ECOM_CODE_page_objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class login_page extends Reuseable_Methods{

	WebDriver driver;
	
	
	public login_page(WebDriver driver) {
		super(driver);
		this.driver=driver ;
		PageFactory.initElements(driver, this);
		
	}
	
	//page factory model
	
	@FindBy(id="userEmail")
	WebElement username;
	
	@FindBy(id="userPassword")
	WebElement password;
	
	@FindBy(id="login")
	WebElement login_button;
	
	
	//get error message
	
	@FindBy(css="[class*='flyInOut']")
	WebElement error_message;
	
	
	//wait error message at login page to appear
	
	
	/*
	WebElement username = driver.findElement(By.id("userEmail")).sendKeys("JOHNDOE@yopmail.com");
	WebElement password =driver.findElement(By.id("userPassword")).sendKeys("BaRWAL#5");
	driver.findElement(By.id("login")).click();
	
	*/
	
	//declaring actions methods for page factory models
	
	
	
	public void hit_login_url_method() {
		driver.get("https://rahulshettyacademy.com/client");
	}
	

	
	@Test(dataProvider="login",dataProviderClass =Reuseable_Methods.class)
	public Product_listing login_to_home_page(String person_email,String person_pswd) {
		username.sendKeys(person_email);
		password.sendKeys(person_pswd);
		login_button.click();
		Product_listing Product_listing_object = new Product_listing(driver);
		return Product_listing_object;
	}
	
	
	public String get_error_message() {
		
		wait_element_to_become_visible(error_message);
		String mess = error_message.getText();
		return mess;
	}
	
}
