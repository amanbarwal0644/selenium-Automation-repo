package ECOM_CODE_page_objects;



import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Extent_report {

ExtentReports ER;
	
	@BeforeTest
	public static ExtentReports config_extent_report() {
		
		ExtentSparkReporter ESR = new ExtentSparkReporter(System.getProperty("user.dir")+"//Reports//chart_report");
		
		ESR.config().setDocumentTitle("Titile:- ECOM Web Report");
		
		ESR.config().setReportName("This is Rahulshetty ECOM Report");
		
		ExtentReports   ER = new ExtentReports();
		ER.attachReporter(ESR);
		ER.setSystemInfo("tester", "Aman");
		ER.setSystemInfo("Developer", "Dhiraj");
		ER.setSystemInfo("Developer", "Abhishek");
		ExtentTest unique_object=ER.createTest("Monitoring init_browser");
		
		return ER;
		
}
}
