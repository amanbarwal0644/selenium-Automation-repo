package ECOM_CODE_page_objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Thankyou_page extends Reuseable_Methods{

	
WebDriver driver;
	
	
	public Thankyou_page(WebDriver driver) {
		super(driver);
		this.driver=driver ;
		PageFactory.initElements(driver, this);
		
	}
	
	
	@FindBy(css=".hero-primary")
	WebElement message;
	
	public String get_thankyou_message() {
		
		String thanks_message = message.getText();
		return thanks_message;
	}
}
