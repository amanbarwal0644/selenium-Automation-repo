package ECOM_CODE_page_objects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class cart extends Reuseable_Methods {

	WebDriver driver;
	public cart(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}
//verify cart product
	@FindBy(css="div[class='cartSection'] h3")
	List<WebElement> cart_page_product_list;

	//click on checkout button
	@FindBy(css="div[class='subtotal cf ng-star-inserted'] ul button")
	WebElement button;
	
	public boolean verify_cart_product(String product_verify) {
		
		boolean match = cart_page_product_list.stream()
				.anyMatch(cart_product -> cart_product.getText().equals(product_verify));
return match;
		
		
	}
	
	
	public Check_out_page click_checkout_button() {
	
		button.click();
		
		Check_out_page check_out_page_obj = new Check_out_page(driver);
		return check_out_page_obj;
		
	}
	
	
}
