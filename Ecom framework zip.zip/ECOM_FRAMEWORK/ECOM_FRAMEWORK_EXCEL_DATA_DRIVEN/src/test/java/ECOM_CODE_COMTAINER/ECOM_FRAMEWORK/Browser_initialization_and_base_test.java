package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Browser_initialization_and_base_test {

	/*WebDriver driver;
	public void browser_details() {
	// Invocation of browser
			WebDriverManager.firefoxdriver().setup();
			WebDriver driver = new FirefoxDriver();
	this.driver=driver;
	driver.manage().window().maximize();
	
}
	*/
public WebDriver driver;
	
public String Take_screenshot(String SNAPSHOTS,WebDriver driver) throws IOException {
		
		TakesScreenshot TS = (TakesScreenshot)driver;
		
		File sc1 = TS.getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(sc1, new File(System.getProperty("user.dir")+"//report//"+SNAPSHOTS+  ".png"));
		
		
		return System.getProperty("user.dir")+"//report//"+SNAPSHOTS+  ".png";
		
		
	}
	
}

		
	

