package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import ECOM_CODE_page_objects.Product_listing;

import ECOM_CODE_page_objects.login_page;
import io.github.bonigarcia.wdm.WebDriverManager;

public class standalone_test extends Browser_initialization_and_base_test{

	@Test(dataProvider="login_Data")
	public void validation(String username, String pswd) {
		// TODO Auto-generated method stub

		
	
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4000));

		String product_to_add = "ADIDAS ORIGINAL";
		

	

		

		// Maximize window
		driver.manage().window().maximize();

		login_page login_page = new login_page(driver);
		login_page.hit_login_url_method();
		login_page.login_to_home_page(username, pswd);
	
		
	
		
	
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		
		

		
		driver.close();
		
	}
	
	
	@DataProvider(name = "login_Data")
	public Object[][]  Login_data() throws IOException {
	    FileInputStream fis = new FileInputStream("C:\\Users\\admin\\ECOM_Test_case_sheet\\My_Test_Cases.xlsx");
	    XSSFWorkbook book = new XSSFWorkbook(fis);

	    XSSFSheet sheet = book.getSheetAt(0);
	    int row = sheet.getPhysicalNumberOfRows();
	    int last_column_index = sheet.getRow(0).getPhysicalNumberOfCells();
  Object data[][] = new Object[row-1][last_column_index];
  
	   for (int i=1;i<row;i++) {
		XSSFRow Data_row =  sheet.getRow(i);
		for(int j=0;j<last_column_index;j++) {
		String cell_data	 = Data_row.getCell(j).toString();
			 
			 data[i-1][j]=cell_data;
		}
	   }
	   return data;
	   
	}
		

	

		


	}



