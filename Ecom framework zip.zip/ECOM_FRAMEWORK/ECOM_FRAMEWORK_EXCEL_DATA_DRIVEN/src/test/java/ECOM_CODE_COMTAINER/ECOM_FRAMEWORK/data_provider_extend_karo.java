package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import org.testng.annotations.Test;

	
	public class data_provider_extend_karo extends Login_Test_case_Fetch_from_Excel {
		@Test(dataProvider="login", dataProviderClass= Login_Test_case_Fetch_from_Excel.class)
		public void get_data_frm_dataprovider(String usrnm, String pswd) {
			
			System.out.println(usrnm+pswd);
			System.out.println();
		}
}
