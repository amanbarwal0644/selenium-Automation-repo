package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import java.io.IOException;
import java.util.ArrayList;

public class test_excel_data_driven {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		Excel_data_driven e1 = new Excel_data_driven();
		ArrayList b = 	e1.getdata_from_excel("Pruchase");
	
	System.out.println(b.get(0));
	System.out.println(b.get(1));
	System.out.println(b.get(2));
	//System.out.println(b.get(3));
	
	}

}
