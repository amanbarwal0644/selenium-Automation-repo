package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class Login_Test_case_Fetch_from_Excel {
	
	

	@DataProvider(name = "login_Data")
	public Object[][]  Login_data() throws IOException {
	    FileInputStream fis = new FileInputStream("C:\\Users\\admin\\ECOM_Test_case_sheet\\My_Test_Cases.xlsx");
	    XSSFWorkbook book = new XSSFWorkbook(fis);

	    XSSFSheet sheet = book.getSheetAt(0);
	    int row = sheet.getPhysicalNumberOfRows();
	    int last_column_index = sheet.getRow(0).getPhysicalNumberOfCells();
  Object data[][] = new Object[row-1][last_column_index];
  
	   for (int i=1;i<row;i++) {
		XSSFRow Data_row =  sheet.getRow(i);
		for(int j=0;j<last_column_index;j++) {
		String cell_data	 = Data_row.getCell(j).toString();
			 
			 data[i-1][j]=cell_data;
		}
	   }
	   return data;
	   
	}
			

}
