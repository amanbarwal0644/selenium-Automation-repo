package ECOM_CODE_COMTAINER.ECOM_FRAMEWORK;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_data_driven {
	
	
	public ArrayList<String> getdata_from_excel(String barwal) throws IOException {
		
		ArrayList<String> a = new ArrayList<String>();
		
		
		FileInputStream fis = new FileInputStream("C:\\Users\\admin\\ECOM_Test_case_sheet\\My_Test_cases.XLSX");
		
		
		XSSFWorkbook  workbook = new XSSFWorkbook(fis);
		
	int number_of_sheet_in_workbook =	workbook.getNumberOfSheets();
	
	System.out.println(number_of_sheet_in_workbook);
	for(int i=0;i<number_of_sheet_in_workbook;i++) {
		if(workbook.getSheetAt(i).getSheetName().equalsIgnoreCase("Barwal")) {
			System.out.println("sheet1 found");
			
		XSSFSheet sheet = 	workbook.getSheetAt(i);
	Iterator<Row> row =	sheet.iterator();
	Row first_row = row.next();
	
	Iterator<Cell> cell = first_row.cellIterator();
	int Column =0;
	while(cell.hasNext()) {
		Cell callv = cell.next();
		
		String value_from_string = callv.getStringCellValue();
		
		System.out.println(value_from_string);
		
		
		if(value_from_string.equalsIgnoreCase("test Cases")) {
			System.out.println("test cases found at column"+callv.getColumnIndex());
			
		 	Column = callv.getColumnIndex();
		}
		}
	
	
while(row.hasNext()) {
	
	Row r = row.next();

	System.out.println(r.getCell(Column).getStringCellValue());
	
	if(r.getCell(Column).getStringCellValue().equalsIgnoreCase(barwal)){
		System.out.println("im inside case you provided in test excel row");
		
		Iterator<Cell> specificrow_cell = r.cellIterator();
	while(specificrow_cell.hasNext()) {
		
		Cell val = specificrow_cell.next();
	if(val.getCellType()== CellType.STRING)
	{
         a.add(val.getStringCellValue());
	}
	
	  else { a.add(NumberToTextConverter.toText(val.
	  getNumericCellValue())); }
	 
	
	
	}
	}
}
	
	}
	
			
			
		}
	return a;
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub


	

	}
		
		
		
		
	}


