package ECOM_CODE_page_objects;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class login_page {

	WebDriver driver;
	
	
	public login_page(WebDriver driver) {
		
		this.driver=driver ;
		PageFactory.initElements(driver, this);
		
	}
	
	//page OBJECT MODEL using Page factory design pattern.
	
	@FindBy(id="userEmail")
	WebElement username;
	
	@FindBy(id="userPassword")
	WebElement password;
	
	@FindBy(id="login")
	WebElement login_button;
	
	
	
	public void hit_login_url_method() {
		driver.get("https://rahulshettyacademy.com/client");
	}
	

	
	
	
	public void  login_to_home_page(String name, String pswd) {
		
		
		
			username.sendKeys(name);
			password.sendKeys(pswd);
			login_button.click();
			
		}
		
	
	//@Test(dataProvider="login_Data")
	
	
	
	
}
