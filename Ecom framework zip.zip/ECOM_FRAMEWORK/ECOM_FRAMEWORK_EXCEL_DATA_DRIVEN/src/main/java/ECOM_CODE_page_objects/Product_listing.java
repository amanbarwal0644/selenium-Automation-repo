package ECOM_CODE_page_objects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Product_listing extends Reuseable_Methods {
	

		WebDriver driver;
		
		
		public Product_listing(WebDriver driver) {
			super(driver);
			this.driver=driver ;
			PageFactory.initElements(driver, this);
			
		}
		
		//page factory model
		//get product contianers
		@FindBy(css=".mb-3")
		List<WebElement> products_container;
		
		
		//wait for product list to appear
		By findby =  By.cssSelector(".mb-3");
		
		//add to cart locator
		By add_to_cart_locator = By.cssSelector(".card-body button:last-of-type");
		
		//wait for toast to appear
		
		By toast = By.cssSelector("#toast-container");
		
		
		// wait to disappear
		By invisible_toast = By.cssSelector(".ng-animating");
	
	
		
		public List<WebElement> products_list() {
			wait_element_to_appear(findby);
			
			return products_container;
		}
		
		
		public    WebElement   get_product_by_name(String product_to_add ) {
			
			WebElement save_return_product = products_list().stream()
					.filter(variable -> variable.findElement(By.tagName("b")).getText().equals(product_to_add)).findFirst()
					.orElse(null);
			return save_return_product;
		}
		
		public void add_item_to_cart(String item_to_add) {
			WebElement item = get_product_by_name(item_to_add);
			item.findElement(add_to_cart_locator).click();
			
			
			wait_element_to_appear(toast);
			
		//	wait_to_disappear(invisible_toast);
			
			
			
			
		}
		
		
		
}
