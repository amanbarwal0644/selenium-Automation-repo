package ECOM_CODE_page_objects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Reuseable_Methods {

	WebDriver driver;
	
	
	
	//page factory for add to cart menu
	
	@FindBy(css="button[routerlink*='cart']")
	WebElement add_to_cart_menu_button;
	
	

	public  Reuseable_Methods(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public void wait_element_to_appear(By Findby) {
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		wait.until(ExpectedConditions.visibilityOfElementLocated(Findby));
		
		
	}

public void wait_element_to_become_visible(WebElement vis) {
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		wait.until(ExpectedConditions.visibilityOf(vis));
		
		
	}

	
	
	
	public void wait_to_disappear(By ele) {
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(ele));
	}
	
	
	
	
	
	
	
	
	
	
	
	

	
}
