package testng_package_for_files2;

import org.testng.annotations.Test;

public class java_file_package2 {

	@Test
	public void towerA() {
		System.out.println("TowerA");
	}
}
