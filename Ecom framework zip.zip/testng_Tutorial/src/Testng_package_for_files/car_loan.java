package Testng_package_for_files;

import org.testng.annotations.Test;

public class car_loan   
	{  
	@Test  
	public void WebLoginCarLoan()  
	{  
	System.out.println("Web Login car Loan");  
	}  
	@Test  
	public void MobileLoginCarLoan()  
	{  
	System.out.println("Mobile Login car Loan");  
	}  
	@Test(groups= {"SmokeTest"})  
	public void APILoginCarLoan()  
	{  
	System.out.println("API Login Loan from  car loan");  
	}  
	}  
	
	