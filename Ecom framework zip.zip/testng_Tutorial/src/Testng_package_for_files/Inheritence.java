package Testng_package_for_files;

import org.testng.annotations.Test;

public class Inheritence  {
	
	


@Test
public void name() {
System.out.println("i am from inheritence class");
}


}
