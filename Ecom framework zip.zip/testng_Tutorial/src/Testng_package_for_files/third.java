package Testng_package_for_files;

import org.testng.annotations.Test;

public class third {
@Test
	public void last() {
		System.out.println("ho vayi");
	}

@Test(groups = {"smoke"})
public void demo_third() {
	System.out.print("smoke_third");
}
	
}
