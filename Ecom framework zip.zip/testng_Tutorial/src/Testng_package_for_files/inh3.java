package Testng_package_for_files;

import org.testng.annotations.Test;

public class inh3 extends inh4{
	
	int a;
	
	//contructor 
	public inh3(int a) {
		super(a);
		this.a=a;
	}

	@Test
	public int increment() {
	 a = a+1;
	return a;
	}
	
	@Test
	public int decrement() {
	 a = a-1;
	return a;
	}
   
	
	
   

}
