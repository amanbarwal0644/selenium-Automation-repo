package Testng_package_for_files;

import static org.testng.Assert.assertFalse;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Personal_loan  
	{  
	@Parameters({"parm1","parm2"})
	 @Test(groups= {"SmokeTest"})  
	 public void WebLoginPersonalLoan(String pa1,String pa2)  
	 {  
	     System.out.println("Web Login Personal Loan from personal loan");  
	 
	     System.out.println(pa1+pa2);
	 
	 }  
	 @Test  
	 public void MobileLoginPersonalLoan()  
	 {  
	     System.out.println("Mobile Login Personal Loan");  
	 }  
	 
	 @Test(dataProvider="dataset")  
	 public void APILoginPersonalLoan(String USR,String PSWD, boolean True)  
	 {  
	     System.out.println("API Login Personal Loan");  
	     
	     System.out.println(USR+PSWD);
	     
	     Assert.assertFalse(True);
	 }  
	 
	 @DataProvider
	 public Object[][] dataset() {
		
		 Object[][] data = new Object[3][2];
		 data[0][0]="user1";
		 data[0][1]="pswd1";
		 
		 //2nd set
		 data[1][0]="user2";
		 data[1][1]="pswd2";
		 
		 // 3rd set
		 
		 data[2][0]="user3";
		 data[2][1]="pswd3";
		 
		 return data;
	 }
	 
	}  



