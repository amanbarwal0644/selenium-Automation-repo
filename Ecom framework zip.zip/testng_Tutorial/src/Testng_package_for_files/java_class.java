package Testng_package_for_files;

public class java_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	tc1();
	tc2();
	}
	public static void tc1() {
		System.out.println("tc1 method");
	}
	
	public static void tc2() {
		System.out.println("tc2 method");
	}
	
	}

