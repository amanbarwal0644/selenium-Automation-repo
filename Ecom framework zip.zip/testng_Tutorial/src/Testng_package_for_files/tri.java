package Testng_package_for_files;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class tri {

	@BeforeMethod
	
	public void t1() {
		System.out.println("t1");
	}
	
	@Test
	public void t2() {
		System.out.println("t2");
	}
	
	@Test
	public void t3() {
		System.out.println("t3");
	}
	
	
	
}
