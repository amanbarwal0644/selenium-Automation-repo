package Testng_package_for_files;

import org.testng.annotations.Test;

public class inherit2 {
	

	@Test
	public void aman() {
		//name();
		inh3 of = new inh3(5);
		
	
		System.out.println(of.increment());
		System.out.println(of.decrement());
		  //of.multiply();
		  System.out.println(of.multiply());
		

      }
}
