package Testng_package_for_files;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Home_loan   
	{  
	@Test  
	public void WebLoginHomeLoan()  
	{  
	  System.out.println("Web Login Home Loan");  
	}  
	
	@Parameters({"parm1","parm2"})
	@Test(groups= {"SmokeTest"})  
	public void MobileLoginHomeLoan(String pa1,String pa2)  
	{  
	  System.out.println("Mobile Login Home Loan from home loan");  
	  System.out.println(pa1+pa2);
		 
	
	}  
	@Test  
	public void APILoginHomeLoan()  
	{  
	  System.out.println("API Login Home Loan");  
	}  
	
	
	
}
