package Testng_package_for_files;

import org.testng.annotations.Test;

public class smoke {

	
	@Test(groups={"smoke"})
	public void smoke1() {
		System.out.println("this is 1st smoke etst case");
	}
	
	public void smoke2() {

		System.out.println("this is 2nd smoke etst case");
	
	}
}
