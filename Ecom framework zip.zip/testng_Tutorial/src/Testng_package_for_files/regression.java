package Testng_package_for_files;

import org.testng.annotations.Test;

public class regression {

	
	public void Reg1() {
		System.out.println("this is 1st reg etst case");
	}
	
	@Test(groups = {"regression"})
	public void Reg2() {

		System.out.println("this is 2nd reg etst case");
	
	}
}
