package Testng_package_for_files;


	import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

	public class forgot_pswd {
 
		@Parameters({"URL","URL2"})
		@Test
		
		public void testng(String aman, String kumar) {
			
			System.out.println("TestNG Method"+aman);
			System.out.println(kumar);
			
		}
		
		
		@Test
		public void forgotcase1method() {
			System.out.println("case1 of forgot password");
			
		}
		
		/*
		 * @Test(groups = {"smoke"}) public void forgot_reg() {
		 * System.out.print("smoke_forgot"); }
		 */
		
		@Test(enabled = true)
		public void amanmethod() {
			System.out.println("aplhabet A");
		}
	}
	

