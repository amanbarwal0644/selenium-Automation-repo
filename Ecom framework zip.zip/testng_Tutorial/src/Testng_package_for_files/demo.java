package Testng_package_for_files;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class demo {

	@AfterTest
	public void demo_tu() {
		System.out.println("After test demo_tu");
	}
	
	
	
	@Test
	public void second_case() {
		System.out.println("bye");
	}
	
	@Test
	public void mobilelogin() {
		System.out.println("mobile experience");
	}
	
	
	@Test
	
	public void mobileforgot() {
		System.out.println("mobile forgot");
	}
	
	@Test 
	public void andriod() {
		System.out.println("android testing");
	}
	
	
	@BeforeMethod
	public void suitmathod() {
		System.out.println("suit block demo class");
	}
	
	@BeforeTest
	public void beforetest() {
		System.out.println("before test demo class");
	}
	
	@AfterTest
	public void after_normal_test() {
		System.out.println("afterTest_normal_test ");
	}
	@AfterMethod
	public void aftermethod() {
		System.out.println("after test method");
	}
	
	
	@BeforeClass
	public void class1() {
		System.out.println ("class1");
	}
	
    @AfterClass
    
    public void class2() {
    	System.out.println("class2");
    }
    
    @Test(groups = {"smoke"})
    public void demo_reg() {
    	System.out.print("smoke_demo");
    }

}
