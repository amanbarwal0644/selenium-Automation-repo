package Testng_package_for_files;

public  class inh4 {
	int a;
	public inh4(int a) {
		// TODO Auto-generated constructor stub
		
		this.a=a;
	}

	public int multiply() {
	// TODO Auto-generated method stub
	a=a*3;
	return a;
}
	}
