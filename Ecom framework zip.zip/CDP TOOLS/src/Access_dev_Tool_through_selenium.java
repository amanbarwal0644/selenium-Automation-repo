import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v114.network.Network;
import org.openqa.selenium.devtools.v114.network.model.Request;
import org.openqa.selenium.devtools.v114.network.model.Response;
import org.openqa.selenium.devtools.v85.emulation.Emulation;

public class Access_dev_Tool_through_selenium {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	//	System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Selenium_browser_driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/angularAppdemo/");
		
	DevTools tool = driver.getDevTools();
	
	tool.createSession();

	
	//Below is indirect call wrapped in send command. 
	//tool.send(Emulation.setDeviceMetricsOverride(412, 914, 50, true, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty()));
	
	
	
	// calling directly CDP methods without selenium
	
	
	
	
	Map<String, Object> deviceconfig = new HashMap();
	
	
	deviceconfig.put("width", 500);
	deviceconfig.put("height", 1000);
	deviceconfig.put("deviceScaleFactor", 50);
	deviceconfig.put("mobile", true);

	
	
	/*
	 deviceConfig.put("latitude", 40.0);
     deviceConfig.put("longitude", 3.0);
     deviceConfig.put("accuracy", 1.0);
*/
	
	// below is direct call from driver
	driver.executeCdpCommand("Emulation.setDeviceMetricsOverride", deviceconfig);
	
	//driver.executeCdpCommand("Emulation.setGeolocationOverride", deviceConfig);
	

	//* below code will capture the network responses of API.	
	
	
	
	
	// step 1 first enable network so that it can track your network response codes.


	DevTools ttol = driver.getDevTools();

	//ttol.createSession();
	ttol.send(Network.enable(Optional.empty(),Optional.empty(),Optional.empty()));
	
	
	ttol.addListener(Network.requestWillBeSent(), request-> {
		
		
		Request req = request.getRequest();
		System.out.println(req.getUrl());
	});
	
	
	
	
	
	
	
	// all the request response of Api will be triggered through events .And events responses will be listened by listeners.
	
//listener will take two parameter event to which he/she listen to and response code
	ttol.addListener(Network.responseReceived(), response->{
		
		System.out.println(response.getResponse().getStatus());
		Response res=response.getResponse();
		System.out.println(res.getStatus());
		System.out.println(res.getUrl());
		
		
	
	
	});
	driver.get("https://rahulshettyacademy.com/angularAppdemo/");
	driver.findElement(By.xpath("//button[@routerlink='/library']")).click();

	
	
	
	
	
	
	
	
	
	
		
		
	}

}
