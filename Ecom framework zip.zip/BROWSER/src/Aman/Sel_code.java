package Aman;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Sel_code {

		
		@Test
		public void gettitle() throws MalformedURLException {
			
			
			 MutableCapabilities caps = new MutableCapabilities();
			 
			WebDriver driver = new RemoteWebDriver(new URL("https://hub.browserstack.com/wd/hub"),caps);
			
		
			driver.get("https://git-scm.com/download/win");
			
		//	assert.assertTrue(driver.getTitle().matches("Git - Downloading Package"));
			
		}
		
		
	}


